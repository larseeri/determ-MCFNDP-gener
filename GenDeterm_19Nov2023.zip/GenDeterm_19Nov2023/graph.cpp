// Copyright (c) 2023 Eric Larsen
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the “Software”), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
//
//
#include "classes.h"

int CommodNode::count = 0;

// Constructor
Graph::Graph(const Data *_data) :
		data(_data), rnd(_data->seed, _data->stream)
{
	numbNodes = data->numbNodes;
	// total number of arcs
	numbArcs = 0;
	// total number of arcs defined while building a gridlike or circular
	// topology, or when reading a basic graph from file
	numbArcsInGrid = 0;
	numbCommods = data->numbCommods;

	commods.resize(numbCommods, numbNodes);
	defineVolumes();
	addArcs();
	adjustArcs();
	defineCommodities();
	adjustArcCapacities();
	adjustFixedCosts();
}

// Generates initial commodity volumes.
void Graph::defineVolumes()
{
	totalVolume = 0;

	for (int k = 0; k < numbCommods; k++)
	{
		commods[k].volume = rnd.getRandom(data->minCommVol,
				data->maxCommVol - data->minCommVol);
		totalVolume += commods[k].volume;
	}
}

// Adds arcs to graph.
void Graph::addArcs()
{

	VectCommodOnArc commodsOnArc;

	// generate commodity related costs and capacities on arcs
	for (int k = 0; k < numbCommods; k++)
	{
		int cost = data->maxVarCost;
		int capac = commods[k].volume;

		commodsOnArc.push_back(CommodOnArc(cost, capac));
	}

	// generate grid like connections between nodes
	if (data->gridConnect)
	{
		for (int j = 0; j < data->lengthY; j++)
			for (int i = 0; i < data->lengthX; i++)
			{
				int node = j * data->lengthX + i;

				addHorizArcsInGrid(node, i, commodsOnArc);
				addVertArcsInGrid(node, i, j, commodsOnArc);
				addRandomArcs(node, 2);
			}
	}
	// generate circular connections between nodes
	else if (data->circConnect)
	{
		for (int n = 0; n < numbNodes; n++)
		{
			int dest = (n < numbNodes - 1) ? n + 1 : 0;

			addArcInGrid(
					Arc(n, dest, data->maxFixedCost, totalVolume,
							commodsOnArc));
		}
	}
	// read basic graph from file
	else if (data->fromFile)
	{
		readBasicGraph(data->basicGraphFileName, commodsOnArc);
	}

	// generate arcs randomly
	addRandomArcs(-1, data->numbAddArcs);
}

// Adds horizontal arcs in grid.
void Graph::addHorizArcsInGrid(int node, int i,
		const VectCommodOnArc &commodsOnArc)
{
	if (data->lengthX > 1)
	{
		if (i > 0 && i < data->lengthX - 1)
		{
			addArcInGrid(
					Arc(node, node + 1, data->maxFixedCost, totalVolume,
							commodsOnArc));

			addArcInGrid(
					Arc(node, node - 1, data->maxFixedCost, totalVolume,
							commodsOnArc));
		}
		else if (i == 0)
		{
			addArcInGrid(
					Arc(node, node + 1, data->maxFixedCost, totalVolume,
							commodsOnArc));
			if (data->lengthX > 2)
				addArcInGrid(
						Arc(node, node + (data->lengthX - 1),
								data->maxFixedCost, totalVolume, commodsOnArc));
		}
		else
		{
			if (data->lengthX > 2)
				addArcInGrid(
						Arc(node, node - (data->lengthX - 1),
								data->maxFixedCost, totalVolume, commodsOnArc));

			addArcInGrid(
					Arc(node, node - 1, data->maxFixedCost, totalVolume,
							commodsOnArc));
		}
	}
}

// Adds vertical arcs in grid.
void Graph::addVertArcsInGrid(int node, int i, int j,
		const VectCommodOnArc &commodsOnArc)
{
	if (data->lengthY > 1)
	{
		if (j > 0 && j < data->lengthY - 1)
		{
			addArcInGrid(
					Arc(node, node + data->lengthX, data->maxFixedCost,
							totalVolume, commodsOnArc));

			addArcInGrid(
					Arc(node, node - data->lengthX, data->maxFixedCost,
							totalVolume, commodsOnArc));
		}
		else if (j == 0)
		{
			addArcInGrid(
					Arc(node, node + data->lengthX, data->maxFixedCost,
							totalVolume, commodsOnArc));
			if (data->lengthY > 2)
				addArcInGrid(
						Arc(node, node + data->lengthX * (data->lengthY - 1),
								data->maxFixedCost, totalVolume, commodsOnArc));
		}
		else
		{
			if (data->lengthY > 2)
				addArcInGrid(
						Arc(node, i, data->maxFixedCost, totalVolume,
								commodsOnArc));

			addArcInGrid(
					Arc(node, node - data->lengthX, data->maxFixedCost,
							totalVolume, commodsOnArc));
		}
	}
}

// Adds circular arcs (i.e. connect nodes sequentially).
void Graph::addCircArcs()
{
	for (int i = 0; i < numbNodes; i++)
	{
		VectCommodOnArc commodsOnArc;
		int fin = (i < numbNodes - 1) ? i + 1 : 0;

		for (int k = 0; k < numbCommods; k++)
			commodsOnArc.push_back(
					CommodOnArc(data->maxVarCost, commods[k].volume));

		addArcInGrid(
				Arc(i, fin, data->maxFixedCost, totalVolume, commodsOnArc));
	}
}

// Returns true if arc has already been generated.
bool Graph::findArc(int orig, int dest)
{
	bool found = false;

	for (int a = 0; a < numbArcs && !found; a++)
		if (arcs[a].orig == orig && arcs[a].dest == dest)
			found = true;

	return found;
}

// Adds arc with random costs and capacities.
void Graph::addRandomArc(int orig, int dest)
{
	int cost = rnd.getRandom(data->minFixedCost,
			data->maxFixedCost - data->minFixedCost);
	int capac = rnd.getRandom(data->minArcCapac,
			data->maxArcCapac - data->minArcCapac);

	Arc arc(orig, dest, cost, capac);

	for (int k = 0; k < numbCommods; k++)
	{
		cost = rnd.getRandom(data->minVarCost,
				data->maxVarCost - data->minVarCost);
		capac = rnd.getRandom(data->minCommCapac,
				data->maxCommCapac - data->minCommCapac);
		arc.addCommodOnArc(CommodOnArc(cost, capac));
	}

	addArc(arc);
}

// Adds arcs with random costs and capacities.
void Graph::addRandomArcs(int nodeInit, int numbAddArcs)
{
	int orig = nodeInit;
	int dest;

	for (int a = 0; a < numbAddArcs; a++)
	{
		int iter = data->maxIterNoParallelArcs;
		bool found = false;

		do
		{
			if (nodeInit < 0)
				orig = rnd.getRandom(0, numbNodes);

			do
				dest = rnd.getRandom(0, numbNodes);
			while (orig == dest);

			if (data->noParallelArcs)
			{
				found = findArc(orig, dest);

				if (found)
					iter--;
				// if cannot find any arc while in noParallelArcs mode,
				// then try again for maxIterNoParallelArcs iterations.
				// If still not found, then the graph will have one less
				// random arc
			}
		} while (found && iter >= 0);

		if (iter >= 0)
			addRandomArc(orig, dest);
	}
}

// Adjusts characteristics of random arcs according to parameters.
void Graph::adjustArcs()
{
	int numbArcsNonGrid = numbArcs - numbArcsInGrid;

	if (data->ratioZeroFixedCost > 0)
	{   // desired number of random arcs with fixed cost set to zero
		int numbArcsToModify = (int) (data->ratioZeroFixedCost * numbArcsNonGrid
				/ 100);

		for (int a = numbArcs - 1; a > numbArcs - numbArcsToModify; a--)
			arcs[a].cost = 0;
	}

	if (data->ratioTotVolCapac > 0)
	{   // desired number of random arcs with capacity set to total volume
		int numbArcsToModify = (int) (data->ratioTotVolCapac * numbArcsNonGrid
				/ 100);

		for (int a = numbArcs - 1; a > numbArcs - numbArcsToModify; a--)
			arcs[a].capac = totalVolume;
	}

	if (data->ratioZeroCommCapac > 0)
	{   // desired number of random arcs with commodity-specific capacity
		// set to zero
		int numbArcsToModify = (int) (data->ratioZeroCommCapac * numbArcsNonGrid
				/ 100);

		for (int a = numbArcs - 1; a > numbArcs - numbArcsToModify; a--)
		{
			int k = rnd.getRandom(0, numbCommods);
			int arc = rnd.getRandom(numbArcsInGrid, numbArcsNonGrid);

			arcs[arc].commodsOnArc[k].capac = 0;
		}
	}

	if (data->ratioMaxCommCapac)
	{   // desired number of random arcs with commodity-specific capacity
		// set to maxArcCapac
		int numbArcsToModify = (int) (data->ratioMaxCommCapac * numbArcsNonGrid
				/ 100);

		for (int a = numbArcs - 1; a > numbArcs - numbArcsToModify; a--)
		{
			int k = rnd.getRandom(0, numbCommods);
			int arc = rnd.getRandom(numbArcsInGrid, numbArcsNonGrid);

			arcs[arc].commodsOnArc[k].capac = data->maxArcCapac;
		}
	}
}

// Defines source(s)/sink(s) of commodities.
void Graph::defineCommodities()
{
	if (!data->oneSourceOneSink)
	{
		if (!data->equSourcesEquSinks)
			defCommsDefault();
		else
			defCommsEquSourcesEquSinks();
	}
	else
		defCommsOneSourceOneSink();
}

// Randomly selects sources and sinks for all commodities while ensuring 
// there is only one source and only one sink for each commodity.
void Graph::defCommsOneSourceOneSink()
{
	VectBool2 odmark(numbNodes, VectBool(numbNodes, false));
	int orig, dest;

	for (int k = 0; k < numbCommods; k++)
		commods[k].numbOrig = commods[k].numbDest = 1;

	for (int k = 0; k < numbCommods; k++)
	{
		do
		{
			orig = rnd.getRandom(0, numbNodes);

			do
				dest = rnd.getRandom(0, numbNodes);
			while (orig == dest);
		} while (odmark[orig][dest]);

		odmark[orig][dest] = true;
		commods[k].commodNodes[orig].volume = commods[k].volume;
		commods[k].commodNodes[dest].volume = -commods[k].volume;
	}
}

// Randomly selects sources and sinks for all commodities while ensuring 
// that sources are identical over all commodities
// and sinks are identical over all commodities.
void Graph::defCommsEquSourcesEquSinks()
{
	VectBool omark(numbNodes, false);
	VectBool dmark(numbNodes, false);
	int nbSources = 0, nbSinks = 0, node, temp;
	int idxOrig = 0, idxDest = 0, surplus = 0;

	nbSources = rnd.getRandom(data->minNumbSources,
			data->maxNumbSources - data->minNumbSources);
	nbSinks = rnd.getRandom(data->minNumbSinks,
			data->maxNumbSinks - data->minNumbSinks);

	for (int i = 0; i < nbSources; i++)
	{
		do
			node = rnd.getRandom(0, numbNodes);
		while (omark[node]);

		omark[node] = true;
	}

	for (int i = 0; i < nbSinks; i++)
	{
		do
			node = rnd.getRandom(0, numbNodes);
		while (dmark[node]);

		dmark[node] = true;
	}

	for (int k = 0; k < numbCommods; k++)
	{
		int totalSupply = 0;
		int totalDemand = 0;

		surplus = 0;

		for (int n = 0; n < numbNodes; n++)
		{
			if (omark[n])
			{
				if (idxOrig == 0)
					idxOrig = n;

				temp = rnd.getRandom(1, (int) (commods[k].volume / nbSources));
				commods[k].commodNodes[n].volume = surplus + temp;
				totalSupply += commods[k].commodNodes[n].volume;
				surplus = (int) (commods[k].volume / nbSources) - temp;
			}
		}

		commods[k].commodNodes[idxOrig].volume += surplus;
		totalSupply += surplus;

		surplus = 0;

		for (int n = 0; n < numbNodes; n++)
		{
			if (dmark[n])
			{
				if (idxDest == 0)
					idxDest = n;

				temp = rnd.getRandom(1, (int) (commods[k].volume / nbSinks));
				commods[k].commodNodes[n].volume = -(surplus + temp);
				totalDemand -= commods[k].commodNodes[n].volume;
				surplus = (int) (commods[k].volume / nbSinks) - temp;
			}
		}

		commods[k].commodNodes[idxDest].volume -= surplus;
		totalDemand -= surplus;
		balanceCommodities(k, totalSupply, totalDemand);
	}
}

// Randomly selects sources and sinks for all commodities without 
// additional conditions.
void Graph::defCommsDefault()
{
	VectBool2 mark(numbCommods, VectBool(numbNodes, false));

	for (int k = 0; k < numbCommods; k++)
	{
		commods[k].numbOrig = rnd.getRandom(data->minNumbSources,
				data->maxNumbSources - data->minNumbSources);
		commods[k].numbDest = rnd.getRandom(data->minNumbSinks,
				data->maxNumbSinks - data->minNumbSinks);
	}

	for (int k = 0; k < numbCommods; k++)
	{
		int surplus = 0, totalSupply = 0, totalDemand = 0, node, index = 0,
				temp;

		for (int s = 0; s < commods[k].numbOrig; s++)
		{
			do
				node = rnd.getRandom(0, numbNodes);
			while (mark[k][node]);

			if (s == 0)
				index = node;

			mark[k][node] = true;
			temp = rnd.getRandom(1,
					(int) (commods[k].volume / commods[k].numbOrig));
			commods[k].commodNodes[node].volume = surplus + temp;
			totalSupply += commods[k].commodNodes[node].volume;
			surplus = (int) (commods[k].volume / commods[k].numbOrig) - temp;
		}

		commods[k].commodNodes[index].volume += surplus;
		totalSupply += surplus;

		surplus = 0;

		for (int s = 0; s < commods[k].numbDest; s++)
		{
			do
				node = rnd.getRandom(0, numbNodes);
			while (mark[k][node]);

			if (s == 0)
				index = node;

			mark[k][node] = true;
			temp = rnd.getRandom(1,
					(int) (commods[k].volume / commods[k].numbDest));
			commods[k].commodNodes[node].volume = -(surplus + temp);
			totalDemand -= commods[k].commodNodes[node].volume;
			surplus = (int) (commods[k].volume / commods[k].numbDest) - temp;
		}

		commods[k].commodNodes[index].volume -= surplus;
		totalDemand += surplus;
		balanceCommodities(k, totalSupply, totalDemand);
	}
}

// Balances supply and demand.
void Graph::balanceCommodities(int k, int totalSupply, int totalDemand)
{
	int n;

	// assign difference to the first source or sink found

	if (totalSupply > totalDemand)
	{
		for (n = 0; n < numbNodes && commods[k].commodNodes[n].volume >= 0; n++)
			;

		commods[k].commodNodes[n].volume -= (totalSupply - totalDemand);
	}
	else if (totalSupply < totalDemand)
	{
		for (n = 0; n < numbNodes && commods[k].commodNodes[n].volume <= 0; n++)
			;

		commods[k].commodNodes[n].volume += (totalDemand - totalSupply);
	}
}

// Adjusts down capacities of arcs according to factor adjFactCapacs.
void Graph::adjustArcCapacities()
{
	if (data->flagAdjCapacsDown)
	{
		int totalCapac = 0;

		for (int a = 0; a < numbArcs; a++)
			totalCapac += arcs[a].capac;

		double q = (double) (numbArcs * totalVolume) / totalCapac;

		for (int a = 0; a < numbArcs; a++)
			arcs[a].capac = min(totalVolume,
					(int) ((q / data->adjFactCapacs) * arcs[a].capac) + 1);
	}
}

// Adjusts up fixed costs of arcs according to factor adjFactFixedCosts.
void Graph::adjustFixedCosts()
{
	if (data->flagAdjFixedCostsUp)
	{
		int totalFixedCost = 0, totalCommodCost = 0;

		for (int a = 0; a < numbArcs; a++)
		{
			totalFixedCost += arcs[a].cost;

			for (int k = 0; k < numbCommods; k++)
				totalCommodCost += arcs[a].commodsOnArc[k].cost;
		}

		totalCommodCost = totalVolume * (totalCommodCost / numbCommods);

		double q = (double) totalFixedCost / totalCommodCost;

		for (int a = 0; a < numbArcs; a++)
			arcs[a].cost = (int) ((data->adjFactFixedCosts / q) * arcs[a].cost)
					+ 1;
	}
}

// Saves generated instance to file.
void Graph::output()
{
	if (data->oneSourceOneSink)
		outputDow("test.dow");

	if (data->noCommCapacs || data->oneSourceOneSink)
		for (int a = 0; a < numbArcs; a++)
			for (int k = 0; k < numbCommods; k++)
				arcs[a].commodsOnArc[k].capac = min(arcs[a].capac,
						commods[k].volume);

	if (data->oneSourceOneSink)
		for (int a = 0; a < numbArcs; a++)
			for (int k = 0; k < numbCommods; k++)
				arcs[a].commodsOnArc[k].cost = arcs[a].commodsOnArc[0].cost;

	if (data->generLpOutFile)
		outputLP("test.lp");
	if (data->generMpsOutFile)
		outputMPS("test.mps");
	if (!data->noStdOutFile)
		outputStd("test.std");

	if (!data->fromFile)
		outputBasicGraph(data->basicGraphFileName);
}

// Reads basic graph (only nodes + arcs) from file without costs or capacities.
void Graph::readBasicGraph(string basicGraphFileName,
		const VectCommodOnArc &commodsOnArc)
{
	ifstream inFile(basicGraphFileName);
	char line[1024];
	string dummy;
	int low, high;  // low and high values for nodes
	int orig, dest;

	inFile.getline(line, 1024);
	inFile.getline(line, 1024);
	inFile >> dummy >> dummy >> low;
	inFile >> dummy >> dummy >> high;

	inFile.getline(line, 1024);
	inFile.getline(line, 1024);
	inFile.getline(line, 1024);
	inFile.getline(line, 1024);

	inFile >> orig >> dest;

	bool foundError = false;
	while (!inFile.eof())
	{
		if (orig >= low && dest <= high)
		{
			orig -= low;
			dest -= low;
			addArcInGrid(
					Arc(orig, dest, data->maxFixedCost, totalVolume,
							commodsOnArc));
		}
		else if (orig < low)
		{
			cout << "ERROR: While reading " + basicGraphFileName + ", Node # "
					<< orig << " is lower than specified low: " << low << endl;

			foundError = true;
		}
		else
		{
			cout << "ERROR: While reading " + basicGraphFileName + ", Node # "
					<< dest << " is higher than specified high: " << high
					<< endl;

			foundError = true;
		}

		inFile >> orig >> dest;
	}

	inFile.close();

	if (foundError)
	{
		exit(1);
	}

	numbNodes = high - low + 1;
}

// Saves basic graph (only nodes + non-random arcs) to file without costs or
// capacities.
void Graph::outputBasicGraph(string basicGraphFileName)
{
	ofstream outFile(basicGraphFileName);

	outFile << "1 Nodes" << endl;
	outFile
			<< "Nodes are identified with integers in closed interval [low, high]. Program will perform appropriate renumbering."
			<< endl;
	outFile << "low = " << 0 << endl;
	outFile << "high = " << numbNodes - 1 << endl << endl;

	outFile << "2 Arcs" << endl;
	outFile << "NodeFrom  NodeTo" << endl;

	for (int a = 0; a < numbArcsInGrid; a++)
		outFile << arcs[a].orig << "  " << arcs[a].dest << endl;

	outFile.close();
}

// Saves generated instance to file with DOW format.
// DOW format imposes additional constraints: for
// each arc capacities and variable costs are identical
// for all commodities.
void Graph::outputDow(string fileName)
{
	ofstream outFile(fileName);
	int orig = 0, dest = 0, volume = 0;

	outFile << " MULTIGEN.DAT:" << endl;
	outFile << setw(8) << right << numbNodes << setw(8) << right << numbArcs
			<< setw(8) << right << numbCommods << endl;

	for (int n = 0; n < numbNodes; n++)
		for (int a = 0; a < numbArcs; a++)
		{
			if (arcs[a].orig == n)
			{
				outFile << setw(8) << right << arcs[a].orig + 1 << setw(8)
						<< right << arcs[a].dest + 1 << setw(8) << right
						<< arcs[a].commodsOnArc[0].cost << setw(8) << right
						<< arcs[a].capac << setw(8) << right << arcs[a].cost
						<< setw(8) << right << 1 << setw(8) << right << a + 1
						<< endl;
			}
		}

	for (int k = 0; k < numbCommods; k++)
	{
		for (int n = 0; n < numbNodes; n++)
		{
			if (commods[k].commodNodes[n].volume > 0)
			{
				orig = n;
				volume = commods[k].commodNodes[n].volume;
			}
			else if (commods[k].commodNodes[n].volume < 0)
				dest = n;
		}

		outFile << setw(8) << right << orig + 1 << setw(8) << right << dest + 1
				<< setw(8) << right << volume << endl;
	}

	outFile.close();
}

// Saves generated instance to file with STD format.
void Graph::outputStd(string fileName)
{
	ofstream outFile(fileName);

	outFile << setw(8) << right << numbNodes << setw(8) << right << numbArcs
			<< setw(8) << right << numbCommods << endl;

	for (int n = 0; n < numbNodes; n++)
		for (int a = 0; a < numbArcs; a++)
		{
			if (arcs[a].orig == n)
			{
				int cpt = 0;

				for (int k = 0; k < numbCommods; k++)
					if (arcs[a].commodsOnArc[k].capac != 0)
						cpt++;

				outFile << setw(8) << right << arcs[a].orig + 1 << setw(8)
						<< right << arcs[a].dest + 1 << setw(8) << right
						<< arcs[a].cost << setw(8) << right << arcs[a].capac
						<< setw(8) << right << cpt << endl;

				for (int k = 0; k < numbCommods; k++)
					if (arcs[a].commodsOnArc[k].capac != 0)
						outFile << setw(8) << right << k + 1 << setw(8) << right
								<< arcs[a].commodsOnArc[k].cost << setw(8)
								<< right << arcs[a].commodsOnArc[k].capac
								<< endl;
			}
		}

	for (int k = 0; k < numbCommods; k++)
		for (int n = 0; n < numbNodes; n++)
			if (commods[k].commodNodes[n].volume != 0)
				outFile << setw(8) << right << k + 1 << setw(8) << right
						<< n + 1 << setw(8) << right
						<< commods[k].commodNodes[n].volume << endl;

	outFile.close();
}

// Saves generated instance to file with (human readable) LP format.
void Graph::outputLP(string fileName)
{
	ofstream outFile(fileName);

	outFile << "\\Problem name: " << fileName << endl << endl;

	string prefix = "Obj: ";
	int coef;
	string var;

	// objective function

	outFile << "Minimize" << endl;

	LPStringBuilder obj(prefix);

	for (int a = 0; a < numbArcs; a++)
	{
		for (int k = 0; k < numbCommods; k++)
		{
			coef = (data->oneSourceOneSink) ?
					arcs[a].commodsOnArc[0].cost : arcs[a].commodsOnArc[k].cost;
			obj.addVar(coef, "X", a, k);
		}
	}

	if (data->integCapacs || data->integCommCapacs)
	{
		for (int a = 0; a < numbArcs; a++)
		{
			obj.addVar(arcs[a].cost, "Y", a);
		}
	}

	outFile << obj << endl;

	outFile << "Subject To" << endl;

	// flow conservation constraints
	for (int n = 0; n < numbNodes; n++)
	{
		for (int k = 0; k < numbCommods; k++)
		{
			prefix = "N_" + to_string(n) + "_" + to_string(k) + ": ";

			LPStringBuilder builder(prefix, "=",
					commods[k].commodNodes[n].volume);

			for (int a = 0; a < numbArcs; a++)
			{
				if (arcs[a].orig == n)
					builder.addVar(1, "X", a, k);
				else if (arcs[a].dest == n)
					builder.addVar(-1, "X", a, k);
			}

			outFile << builder << endl;
		}
	}

	// arc capacities
	if (numbCommods > 1
			|| (numbCommods == 1 && (data->integCapacs || data->integCommCapacs)))
	{
		for (int a = 0; a < numbArcs; a++)
		{
			prefix = "A_" + to_string(a) + ": ";

			LPStringBuilder builder(prefix);

			for (int k = 0; k < numbCommods; k++)
				builder.addVar(1, "X", a, k);

			if ((data->integCapacs
					|| (numbCommods == 1 && data->integCommCapacs))
					&& arcs[a].capac != 0)
			{
				builder.addVar(-arcs[a].capac, "Y", a);
				builder.addRhs("<=", 0);
			}
			else if (!data->integCapacs && numbCommods > 1)
				builder.addRhs("<=", arcs[a].capac);

			outFile << builder << endl;
		}
	}

	// commodity-specific capacities on arcs
	if (numbCommods > 1 && data->integCommCapacs)
	{
		for (int a = 0; a < numbArcs; a++)
		{
			for (int k = 0; k < numbCommods; k++)
			{
				prefix = "K_" + to_string(a) + "_" + to_string(k) + ": ";

				LPStringBuilder builder(prefix, "<=", 0);

				builder.addVar(1, "X", a, k);
				builder.addVar(-arcs[a].commodsOnArc[k].capac, "Y", a);

				outFile << builder << endl;
			}
		}
	}

	// Bounds
	outFile << "Bounds" << endl;

	if (numbCommods == 1
			&& (!(data->integCapacs || data->integCommCapacs)
					|| data->oneSourceOneSink))
	{
		for (int a = 0; a < numbArcs; a++)
		{
			string name = "X_" + to_string(a) + "_0";

			outFile << "0 <= " << name << " <= " << arcs[a].capac << endl;
		}
	}

	if (!data->integCommCapacs && numbCommods > 1 && !data->oneSourceOneSink)
	{
		for (int a = 0; a < numbArcs; a++)
		{
			for (int k = 0; k < numbCommods; k++)
			{
				string name = "X_" + to_string(a) + "_" + to_string(k);

				outFile << "0 <= " << name << " <= "
						<< arcs[a].commodsOnArc[k].capac << endl;
			}
		}
	}

	if (data->integCapacs || data->integCommCapacs)
	{
		for (int a = 0; a < numbArcs; a++)
		{
			string name = "Y_" + to_string(a);

			outFile << "0 <= " << name << " <= " << 1 << endl;
		}

		// Binary variables
		outFile << "Binaries" << endl;

		LPStringBuilder bounds;

		for (int a = 0; a < numbArcs; a++)
		{
			string name = "Y_" + to_string(a) + " ";

			bounds.addVar(name);
		}

		outFile << bounds << endl;
	}

	outFile << "End" << endl;
	outFile.close();
}

// Saves generated instance to file with MPS format.
void Graph::outputMPS(string fileName)
{
	ofstream outFile(fileName);
	int coef;
	string varID, ctrID;

	outFile << "NAME  " << fileName << endl << endl;

	outFile << "ROWS  " << fileName << endl << endl;

	outFile << " N  Obj" << endl;

	for (int n = 0; n < numbNodes; n++)
		for (int k = 0; k < numbCommods; k++)
			outFile << " E  N_" << to_string(n) << "_" << to_string(k) << endl;

	if (numbCommods > 1
			|| (numbCommods == 1 && (data->integCapacs || data->integCommCapacs)))
		for (int a = 0; a < numbArcs; a++)
			outFile << " L  A_" << to_string(a) << endl;

	if (numbCommods > 1 && data->integCommCapacs)
		for (int a = 0; a < numbArcs; a++)
			for (int k = 0; k < numbCommods; k++)
				outFile << " L  K_" << to_string(a) << "_" << to_string(k)
						<< endl;

	outFile << "COLUMNS" << endl;

	// X variables
	for (int a = 0; a < numbArcs; a++)
		for (int k = 0; k < numbCommods; k++)
		{
			varID = "    X_" + to_string(a) + "_" + to_string(k);

			// objective coefficients

			ctrID = "Obj";
			coef = (data->oneSourceOneSink) ?
					arcs[a].commodsOnArc[0].cost : arcs[a].commodsOnArc[k].cost;
			outFile << setw(16) << left << varID << setw(15) << ctrID
					<< setw(10) << coef << endl;

			// flow conservation constraints coefficients
			for (int n = 0; n < numbNodes; n++)
			{
				coef = (arcs[a].orig == n) ? 1 : ((arcs[a].dest == n) ? -1 : 0);

				if (coef != 0)
				{
					ctrID = "N_" + to_string(n) + "_" + to_string(k);
					outFile << setw(16) << left << varID << setw(15) << ctrID
							<< setw(10) << coef << endl;
				}
			}

			// arc capacities constraints coefficients
			if (numbCommods > 1
					|| (numbCommods == 1
							&& (data->integCapacs || data->integCommCapacs)))
			{
				ctrID = "A_" + to_string(a);
				coef = 1;
				outFile << setw(16) << left << varID << setw(15) << ctrID
						<< setw(10) << coef << endl;
			}

			// commodity-specific capacities on arcs coefficients
			if (numbCommods > 1 && data->integCommCapacs)
			{
				ctrID = "K_" + to_string(a) + "_" + to_string(k);
				coef = 1;
				outFile << setw(16) << left << varID << setw(15) << ctrID
						<< setw(10) << coef << endl;
			}
		}

	// Y variables
	outFile << "    MARK0000  'MARKER'                 'INTORG'" << endl;

	bool test =
			(numbCommods > 1 && data->integCapacs)
					|| (numbCommods == 1
							&& (data->integCapacs || data->integCommCapacs));

	for (int a = 0; a < numbArcs; a++)
	{
		varID = "    Y_" + to_string(a);

		// objective coefficient
		ctrID = "Obj";

		if (data->integCapacs || data->integCommCapacs)
		{
			coef = arcs[a].cost;
			outFile << setw(16) << left << varID << setw(15) << ctrID
					<< setw(10) << coef << endl;
		}

		// arc capacities constraints coefficients
		if (test && arcs[a].capac != 0)
		{
			ctrID = "A_" + to_string(a);
			coef = -arcs[a].capac;
			outFile << setw(16) << left << varID << setw(15) << ctrID
					<< setw(10) << coef << endl;
		}

		// commodity-specific capacities on arcs coefficients
		if (numbCommods > 1 && data->integCommCapacs)
		{
			for (int k = 0; k < numbCommods; k++)
			{
				ctrID = "K_" + to_string(a) + "_" + to_string(k);
				coef = -arcs[a].commodsOnArc[k].capac;
				outFile << setw(16) << left << varID << setw(15) << ctrID
						<< setw(10) << coef << endl;
			}
		}
	}

	outFile << "    MARK0000  'MARKER'                 'INTEND'" << endl;

	// RHS

	outFile << "RHS" << endl;
	varID = "    rhs";

	// flow conservation constraints
	for (int n = 0; n < numbNodes; n++)
	{
		for (int k = 0; k < numbCommods; k++)
		{
			if (commods[k].commodNodes[n].volume != 0)
			{
				ctrID = "N_" + to_string(n) + "_" + to_string(k);
				coef = commods[k].commodNodes[n].volume;
				outFile << setw(16) << left << varID << setw(15) << ctrID
						<< setw(10) << coef << endl;
			}
		}
	}

	// arc capacities
	if (numbCommods > 1 && !data->integCapacs)
	{
		for (int a = 0; a < numbArcs; a++)
		{
			ctrID = "A_" + to_string(a);
			coef = arcs[a].capac;
			outFile << setw(16) << left << varID << setw(15) << ctrID
					<< setw(10) << coef << endl;
		}
	}

	// BOUNDS
	outFile << "BOUNDS" << endl;

	if (numbCommods == 1 && !(data->integCapacs || data->integCommCapacs))
	{
		for (int a = 0; a < numbArcs; a++)
		{
			varID = "X_" + to_string(a) + "_0";
			outFile << setw(16) << left << " UP BOUND" << setw(15) << varID
					<< setw(10) << arcs[a].capac << endl;
		}
	}

	if (numbCommods > 1 && !data->integCommCapacs && !data->oneSourceOneSink)
	{
		for (int a = 0; a < numbArcs; a++)
		{
			for (int k = 0; k < numbCommods; k++)
			{
				varID = "X_" + to_string(a) + "_" + to_string(k);
				outFile << setw(16) << left << " UP BOUND" << setw(15) << varID
						<< setw(10) << arcs[a].commodsOnArc[k].capac << endl;
			}
		}
	}

	if (data->integCapacs || data->integCommCapacs)
	{
		for (int a = 0; a < numbArcs; a++)
		{
			varID = "Y_" + to_string(a);
			outFile << setw(16) << left << " BV BOUND" << setw(15) << varID
					<< endl;
		}
	}

	outFile << "ENDATA" << endl;
}

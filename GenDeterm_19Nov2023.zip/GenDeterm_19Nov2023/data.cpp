// Copyright (c) 2023 Eric Larsen
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the “Software”), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
// ****************************************************************************
// ****************************************************************************
//
//
#include "classes.h"

// Constructor
Data::Data(int argc, char **argv, string fileName) :
		paramProcessing(argc, argv, fileName), gridConnect(false), circConnect(
				false), noParallelArcs(false), oneSourceOneSink(false), equSourcesEquSinks(
				false), noStdOutFile(false), generLpOutFile(false), generMpsOutFile(
				false), flagAdjFixedCostsUp(false), flagAdjCapacsDown(false), integCapacs(
				false), integCommCapacs(false), noCommCapacs(false), stream(
				101), seed(101), lengthX(2), lengthY(2), numbNodes(4), numbCommods(
				1), numbAddArcs(0), minNumbSources(1), maxNumbSources(1), minNumbSinks(
				1), maxNumbSinks(1), minCommVol(0), maxCommVol(10000), minFixedCost(
				0), maxFixedCost(10000), minVarCost(0), maxVarCost(10000), minArcCapac(
				1), maxArcCapac(10000), minCommCapac(0), maxCommCapac(10000), adjFactCapacs(
				1.0), adjFactFixedCosts(1.0), ratioZeroFixedCost(0), ratioTotVolCapac(
				0), ratioZeroCommCapac(0), ratioMaxCommCapac(0), maxIterNoParallelArcs(
				0), outFileName("outFile.dat"), basicGraphFileName(
				"basicGraph.dat")
{

	// sets the base topology of the network (see switch below for details)
	int topology;
	bool help = false;

	// reading parameters from file and overriding with command line if present
	readParams("stream", "stream", stream, 0, INT_MAX);
	readParams("seed", "seed", seed, 0, INT_MAX);
	readParams("lengthX", "lengthX", lengthX, 1, INT_MAX);
	readParams("lengthY", "lengthY", lengthY, 1, INT_MAX);
	readParams("numbNodes", "numbNodes", numbNodes, 1, INT_MAX);
	readParams("nbCom", "nbCom", numbCommods, 0, INT_MAX);
	readParams("nbAddArc", "nbAddArc", numbAddArcs, 0, INT_MAX);
	readParams("minNbSrc", "minNbSrc", minNumbSources, 1, INT_MAX);
	readParams("maxNbSrc", "maxNbSrc", maxNumbSources, 1, INT_MAX);
	readParams("minNbSnk", "minNbSnk", minNumbSinks, 1, INT_MAX);
	readParams("maxNbSnk", "maxNbSnk", maxNumbSinks, 1, INT_MAX);
	readParams("minComVol", "minComVol", minCommVol, 1, INT_MAX);
	readParams("maxComVol", "maxComVol", maxCommVol, 1, INT_MAX);
	readParams("minVarCos", "minVarCos", minVarCost, 0, INT_MAX);
	readParams("maxVarCos", "maxVarCos", maxVarCost, 0, INT_MAX);
	readParams("minArcCap", "minArcCap", minArcCapac, 1, INT_MAX);
	readParams("maxArcCap", "maxArcCap", maxArcCapac, 1, INT_MAX);
	readParams("minFixCos", "minFixCos", minFixedCost, 0, INT_MAX);
	readParams("maxFixCos", "maxFixCos", maxFixedCost, 0, INT_MAX);
	readParams("minComCap", "minComCap", minCommCapac, 0, INT_MAX);
	readParams("maxComCap", "maxComCap", maxCommCapac, 0, INT_MAX);
	readParams("ratZeroFix", "ratZeroFix", ratioZeroFixedCost, 0, 100);
	readParams("ratTotVolCap", "ratTotVolCap", ratioTotVolCapac, 0, 100);
	readParams("ratZeroComCap", "ratZeroComCap", ratioZeroCommCapac, 0, 100);
	readParams("ratMaxComCap", "ratMaxComCap", ratioMaxCommCapac, 0, 100);
	readParams("noParalArc", "noParalArc", noParallelArcs,
			maxIterNoParallelArcs, 0,
			INT_MAX);
	readParams("adjCapacDown", "adjCapacDown", flagAdjCapacsDown, adjFactCapacs,
			0,
			INT_MAX);
	readParams("adjFixCosUp", "adjFixCosUp", flagAdjFixedCostsUp,
			adjFactFixedCosts, 0,
			INT_MAX);
	readParams("outFileName", "outFileName", outFileName);
	readParams("basicGraphFileName", "basicGraphFileName", basicGraphFileName);
	readParams("oneSrcOneSnk", "oneSrcOneSnk", oneSourceOneSink);
	readParams("eqSrcsEqSnks", "eqSrcsEqSnks", equSourcesEquSinks);
	readParams("mpsOut", "mpsOut", generMpsOutFile);
	readParams("lpOut", "lpOut", generLpOutFile);
	readParams("intCaps", "intCaps", integCapacs);
	readParams("intCommCaps", "intCommCaps", integCommCapacs);
	readParams("noComCaps", "noComCaps", noCommCapacs);
	readParams("noStdOut", "noStdOut", noStdOutFile);
	readParams("topology", "topology", topology, 0, 3);
	readParams("help", "help", help);

	if (help)
	{
		printHelpAndExit();
	}

	switch (topology)
	{
	case 0:
		gridConnect = false;
		circConnect = false;
		fromFile = false;
		break;

	case 1:
		gridConnect = true;
		circConnect = false;
		fromFile = false;
		numbNodes = lengthX * lengthY;
		cout << "NumbNodes has been set to " << numbNodes
				<< " since the grid connection has been selected!" << endl;
		break;

	case 2:
		gridConnect = false;
		circConnect = true;
		fromFile = false;
		break;

	case 3:
		gridConnect = false;
		circConnect = false;
		fromFile = true;
		break;

	default:
		cerr << "topology must fall in {0, 1, 2, 3}" << endl;
		printUsageAndExit(0, true);
		exit(1);
	}

	validateParams();
}

void Data::displayError(string error)
{
	cerr << error << endl;
	printUsageAndExit(0, true);
	exit(1);
}

// Validates data that should lie inside an interval.
template<class T>
void Data::validateParams(string name, const T &var, const T minVal,
		const T maxVal)
{
	if (var < minVal || var > maxVal)
	{
		cerr << name << " must be between [" << minVal << " , " << maxVal << "]"
				<< endl;
		printUsageAndExit(0, true);
		exit(1);
	}
}

// Cross-validates data.
void Data::validateParams()
{
	if (numbCommods > 1 && !oneSourceOneSink && !noCommCapacs)
	{
		maxCommCapac = min(maxCommCapac, minCommVol);
		maxCommCapac = min(maxCommCapac, minArcCapac);
		minCommCapac = min(minCommCapac, maxCommCapac);

		maxArcCapac = min(maxArcCapac, numbCommods * minCommCapac);
		minArcCapac = min(minArcCapac, maxArcCapac);
		maxCommCapac = min(maxCommCapac, minArcCapac);

		if (minNumbSources > maxNumbSources)
			displayError("minNbSrc > maxNbSrc");
		if (minNumbSinks > maxNumbSinks)
			displayError("minNbSnk > maxNbSnk");
		if (minCommVol > maxCommVol)
			displayError("minComVol > maxComVol");
		if (minVarCost > maxVarCost)
			displayError("minVarCos > maxVarCos");
		if (minFixedCost > maxFixedCost)
			displayError("minFixCos > maxFixCos");
		if (minArcCapac > maxArcCapac)
			displayError("minArcCap > maxArcCap");
		if (minCommCapac > maxCommCapac)
			displayError("minComCap > maxComCap");
		if (lengthX == 1 && lengthY == 1)
			displayError("1x1 network inadmissible");
		if (maxNumbSources + maxNumbSinks > lengthX * lengthY)
			displayError("maxNbSrc+maxNbSnk > lengthX*lengthY");
	}
}

// Methods reading parameter values from parameter file and command line
// (first parameter is name used on the command line,
// second parameter is name used in parameter file)

template<class T>
void Data::readParams(string nameOnCommLine, string nameInFile, T &var,
		const T minVal, const T maxVal)
{
	paramProcessing.assignParamValue(nameOnCommLine, nameInFile, var);
	validateParams(nameInFile, var, minVal, maxVal);
}

template<class T>
void Data::readParams(string nameOnCommLine, string nameInFile, bool &flag,
		T &var, const T minVal, const T maxVal)
{
	flag = paramProcessing.assignParamValue(nameOnCommLine, nameInFile, var);
	validateParams(nameInFile, var, minVal, maxVal);
}

void Data::readParams(string nameOnCommLine, string nameInFile, string &var)
{
	paramProcessing.assignParamValue(nameOnCommLine, nameInFile, var);
}

void Data::readParams(string nameOnCommLine, string nameInFile, char *var)
{
	paramProcessing.assignParamValue(nameOnCommLine, nameInFile, var);
}

void Data::readParams(string nameOnCommLine, string nameInFile, bool &var)
{
	paramProcessing.assignParamValue(nameOnCommLine, nameInFile, var);
}

void Data::printHelpAndExit()
{
	printf(
			"\nThis application randomly generates instances of the deterministic\n");
	printf(
			"multi-commodity, fixed charge, capacitated network design problem.\n");
	printf(
			"Details of this process are governed by user-specified configuration\n");
	printf("settings.\n");

	printf("\n1 Building the program:\n");

	printf("\nUnder Linux, follow these steps to build the program:\n");

	printf("a- Open the archive file containing the program\n");
	printf("b- Go to the directory just created\n");
	printf("c- Run this command: make\n");
	printf("d- An executable file named 'exe' will be created\n");

	printf("\n2 Running the program:\n");

	printf(
			"\nThe program can be run with default option parameter values as follows:\n");

	printf("\n./exe\n");

	printf(
			"\nBy default, the program will read some options from the test.par file.\n");
	printf(
			"(This default setting can be updated by modifying line 75 in file\n");
	printf(
			"main.cpp.) The default file name can be overridden with the option +F:\n");

	printf("\n./exe +F newParamfile.txt\n");

	printf("\nThe option parameters file should have this format:\n");

	printf("\noptionParameter1   <value>\n");
	printf("optionParameter2   <value>\n");
	printf(".\n");
	printf(".\n");
	printf("optionParameterN   <value>\n");

	printf(
			"\nFor options expecting boolean values, no values will be read: presence\n");
	printf(
			"of option name is sufficient to toggle the corresponding value to true.\n");
	printf("By default, boolean values are set to false.\n");

	printf(
			"For other options expecting string, integer or double values, values should\n");
	printf("be specified.\n");

	printf(
			"\nVerbosity option (+v) can be used to get more information about all\n");
	printf(
			"options that have been set in the parameter file or on the command line:\n");

	printf("\n./exe -v\n");

	printf(
			"\nValues set on the command line will override those from the parameter file\n");
	printf(
			"which will in turn override the hard-coded values in data.cpp file\n");

	printf(
			"\nTo display the list of all options available, use option (-help):\n");

	printf("\n./exe -help\n");

	printf("\nExample of a valid command line:\n");

	printf("\n./exe +F newParamFile.txt -stream 1234 -seed 4567 -nbCom 10\n");

	printf(
			"\nIn this example, the final value for parameters 'stream', 'seed' and 'nbCom'\n");
	printf(
			"will be retrieved from command line, and all other parameters appearing\n");
	printf(
			"in 'newParamFile.txt' will have their value taken from there.  Parameters\n");
	printf(
			"that appear neither in the command line nor in the parameter file, will be\n");
	printf("set to the default values defined in data.cpp.\n");

	printf(
			"\nSetting a subset or all of options values, even more than once, is possible.\n");
	printf(
			"In this latter case, the last value assigned will be retained. For example,\n");
	printf("from this command line:\n");

	printf(
			"\n./exe +F newParamFile.txt -stream 1234 -seed 4567 -nbCom 10 -seed 1212\n");

	printf("\nthe value retained for seed will be 1212 (not 4567).\n");

	printf("READING and WRITING the basic graph from and to a filen\n");

	printf(
			"\nCalling the topology option with the value 3 instructs the program to read\n");
	printf(
			"the basic graph (nodes + arcs without costs and capacities) from a plain\n");
	printf(
			"text file. The default name of this file is basicGraph.dat. An alternative\n");
	printf(
			"name may be specified with the option basicGraphFileName. To be read\n");
	printf("correctly, this file must be structured as follows:\n");

	printf("/n(beginning of file)\n");
	printf("Two blank or comment rows (are disregarded when reading)\n");
	printf(
			"low = lowNodeNumber #lowNodeNumber is smallest node number appearing in rows below\n");
	printf(
			"high = highNodeNumber #highNodeNumber is highest node number appearing in rows below\n");
	printf("Three blank or comment rows (are disregarded when reading)\n");
	printf(
			"<origNodeNumber> <destNodeNumber> #a row indicates arc in graph from orig. to dest.\n");
	printf("<origNodeNumber> <destNodeNumber>\n");
	printf("<origNodeNumber> <destNodeNumber>\n");
	printf(".\n");
	printf(".\n");
	printf(".\n");
	printf("(end of file)\n");

	printf(
			"\nIf topology is NOT called with the value 3, then the program will save the\n");
	printf(
			"basic graph in a plain text file whose default name, basicGraph.dat, may\n");
	printf(
			"be superseded using the option basicGraphFileName. In this case, the file\n");
	printf("will have the following appearance:\n");

	printf("/n(beginning of file)\n");
	printf("1 Nodes\n");
	printf(
			"Nodes are identified with integers in closed interval [low, high]. Program will perform appropriate renumbering.\n");
	printf("low = 0\n");
	printf("high = 11\n");

	printf("\n2 Arcs\n");
	printf("NodeFrom  NodeTo\n");
	printf("0  1\n");
	printf("0  2\n");
	printf("0  3\n");
	printf("0  9\n");
	printf(".\n");
	printf(".\n");
	printf(".\n");
	printf("(end of file)\n");

	printUsageAndExit(0, true);
	exit(1);

}

void Data::printUsageAndExit(char ExecName[], bool anonymous)

{
	if (!anonymous)
	{
		printf("\nUsage: %s [options]\n", ExecName);
	}
	else
	{
		printf("Usage of options\n");
	}

	printf("\n1 Options available on command line only\n");
	printf(
			"\n+F <string>; name of file supplying option parameter values\n(any item in this file supersedes item in file with name hard-coded\nin main.cpp; items in both files superseded by items specified on command line)\n");
	printf("\n+v <> (no value supplied); requests verbosity\n");

	printf("\n2 Options available on command line and in configuration file\n");
	printf("(Omit dash prefix (-) in configuration file.)\n");

	printf("\n-h <> (no value supplied); display help message\n");

	printf(
			"\n- <string>; name of output file, suffix will differ\naccording to format: DOW, LP, STD, MPS\n");

	printf(
			"\nDOW and STD formats are specific to MCFND problems and described in files\n");
	printf(
			"DOW-format-desc.txt and STD-format-desc.txt; DOW presupposes that for each\n");
	printf(
			"arc, capacities and variable costs are identical for all commodities;\n");
	printf("LP supplies a generic human readable statement\n");

	printf("\n-mpsOut <> (no value supplied); save output with MPS format\n");
	printf(
			"\n-lpOut <> (no value supplied); save output with human readable\nLP format\n");
	printf(
			"\n-noStdOut <> (no value supplied); do not save output with\nSTD format\n");

	printf("\n-stream <int: 0, INT_MAX>; random stream\n");
	printf("\n-seed <int: 0, INT_MAX>; random seed\n");
	printf(
			"\n-topology <int: 0, 1, 2, 3>; graph topology: 0 random, 1 grid, 2 circular,\n3 read basic graph (nodes + arcs without costs and capacities) from file\n");
	printf(
			"\n-basicGraphFileName <string>; name of file where basic graph will be read if\ntopology==3 and will be written if topology!=3\n");

	printf("\n-lengthX <int: 1, INT_MAX>; length along X if grid topology\n");
	printf("\n-lengthY <int: 1, INT_MAX>; length along Y if grid topology\n");

	printf(
			"\n-numbNodes <int: 1, INT_MAX>; number of nodes if random or circular topology\n");
	printf(
			"\n-oneSrcOneSnk <> (no value supplied); impose one source and one\n");
	printf(
			"sink for each commodity; impose also that for each arc, capacities and\n");
	printf(
			"variable costs are identical for all commodities; will then output at\n");
	printf("least with DOW format\n");

	printf(
			"\n-eqSrcsEqSnks <> (no value supplied); impose identical sources\nand identical sinks for tall commodities\n");
	printf(
			"\nIf oneSrcOneSnk and eqSrcsEqSnks are set to false then sources\nand sinks are selected randomly\n");
	printf(
			"\n-intCaps <> (no value supplied); impose integer total arc\ncapacities\n");
	printf(
			"\n-intCommCaps <> (no value supplied); impose integer commodity\nspecific arc capacities\n");
	printf(
			"\n-noComCaps <> (no value supplied); do not impose commodity specific\narc capacities\n");
	printf("\n-nbCom <int: 0, INT_MAX>; number of commodities\n");
	printf("\n-nbAddArc <int: 0, INT_MAX>; number of additional random arcs\n");
	printf("\n-minNbSrc <int: 1, INT_MAX>; min number of sources\n");
	printf("\n-maxNbSrc <int: 1, INT_MAX>; max number of sources\n");
	printf("\n-minNbSnk <int: 1, INT_MAX>; min number of sinks\n");
	printf("\n-maxNbSnk <int: 1, INT_MAX>; max number of sinks\n");
	printf("\n-minComVol <int: 1, INT_MAX>; min commodity volume\n");
	printf("\n-maxComVol <int: 1, INT_MAX>; max commodity volume \n");
	printf("\n-minVarCos <int: 0, INT_MAX>; min variable cost\n");
	printf("\n-maxVarCos <int: 0, INT_MAX>; max variable cost\n");
	printf("\n-minArcCap <int: 1, INT_MAX>; min arc total capacity\n");
	printf("\n-maxArcCap <int: 1, INT_MAX>; max arc total capacity\n");
	printf("\n-minFixCos <int: 0, INT_MAX>; min fixed cost\n");
	printf("\n-maxFixCos <int: 0, INT_MAX>; max fixed cost\n");
	printf(
			"\n-minComCap <int: 0, INT_MAX>; min commodity-specific arc capacity\n");
	printf(
			"\n-maxComCap <int: 0, INT_MAX>; max commodity-specific arc capacity\n");
	printf(
			"\n-ratZeroFix <int: 0, 100>; percent random arcs with fixed\ncost set to zero\n");
	printf(
			"\n-ratTotVolCap <int: 0, 100>; percent random arcs with total\ncapacity set to total volume\n");
	printf(
			"\n-ratZeroComCap <int: 0, 100>; percent random arcs with a\ncommodity specific capacity set to zero\n");
	printf(
			"\n-ratMaxComCap <int: 0, 100>; percent random arcs with a\ncommodity specific capacity set to maxComCap\n");
	printf(
			"\n-noParalArc <> (no value supplied); avoidance of parallel arcs\n");

	printf(
			"\n-maxIterNoParallelArc <int: 0, INT_MAX>; when adding random arcs,\nnumber of failed attempts to add a non parrallel arc until number of\nrandom arcs to be added is decreased by one\n");
	printf(
			"\n-flagAdjCapacsDown <> (no value supplied); require proportional\nuniform downward\nadjustment of arc capacities according to adjCapacDown\n");
	printf(
			"\n-adjCapacDown <int: 0, INT_MAX>; percent uniform adjustment of\narc capacities\n");
	printf(
			"\n-flagAdjFixedCostsUp <> (no value supplied); require proportional\nuniform upward tadjustment of fixed costs according to adjFixedCosUp\n");

	printf(
			"\n-adjFixCosUp <int: 0, INT_MAX>; percent uniform upward adjustment of\nfixed costs\n");

	exit(1);
}

// Copyright (c) 2023 Eric Larsen
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the “Software”), to
// deal in the Software without restriction, including without limitation the
// rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
// sell copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
// FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
// IN THE SOFTWARE.
// ****************************************************************************
// ****************************************************************************
//
//
#ifndef _STRUCPARAM_H_
#define _STRUCPARAM_H_

#include <sstream>
#include <string>
#include <map>
#include <locale>
#include <iostream>
#include <fstream>
#include <cstring>


using namespace std;

namespace PARAM
{
// default name of configuration file
#define DEFAULT_CONFIG_FILE_NAME         "config.dat"

// default value of boolean variables
#define DEFAULT_BOOL        true

// prefix of all parameters, except configuration file related
#define PARAM_PREFIX     '-'

// prefix of parameters related to configuration file and to reading
// of configuration file
#define CONFIG_PREFIX '+'

// prefix of non-default configuration file name
#define CONFIG_FILE_PREFIX   "+F"

// requesting verbose mode when looking for configuration file
#define CONFIG_VERBOSE_MODE       "+v"

// Class ParamProcessing handles processing of parameter values supplied
// in configuration file and/or on command line.
//
// Attempts to parse the following configuration files are successively
// made: 
// (i) file with default name DEFAULT_CONFIG_FILE_NAME,
// (ii) a file whose name may be specified in constructor,
// (iii) a file whose name may be specified in command line using +F.
// For any parameter, the corresponding value available in (iii) will
// supersede that available in (i) and (ii) and the value available in
// (ii) will supersede that available in (i).
// A configuration file may contain comments either at beginning of
// lines, in which case they must begin with a non alphabetic character,
// or at the end of lines.
//
// Parameter values supplied in configuration files may be modified or 
// supplemented with parameter values supplied in command line.
// Boolean parameters appearing in configuration file or in command line
// without associated value will be given default value DEFAULT_BOOL.
//
// Parameter names appearing in command line must be prefixed with "-" 
// as follows: -parameter_name parameter_value, except for the following 
// exceptions:
// +F when specifying a configuration file
// +v when requesting verbose mode while parsing configuration file names.

class ParamProcessing
{
public:

	// Constructor
	ParamProcessing(int argc, char **argv, string fileName = "");
	// 1st param.: number of values specified on command line
	// 2nd param.: pointer to command line
	// 3rd param.: name of configuration file
	// (This name can be overridden through command line by
	// introducing +F followed by the new file name.)

	template<class T>
	bool assignParamValue(const string &cmdString,
			const string &configFileString, T &var) const;

	bool assignParamValue(const string &cmdString,
			const string &configFileString, bool &var) const;

	bool assignParamValue(const string &cmdString,
			const string &configFileString, char *var) const;

	bool assignParamValue(const string &cmdString,
			const string &configFileString, string &var) const;

	// assignParamValue determines the value to be assigned to a parameter.
	// It will return false if the parameter value is available neither from
	// command line nor from a configuration file.
	//
	// cmdString is the parameter name expected when parsing the command line.
	// configFileString is the parameter name expected when parsing the
	// configuration file.
	// var is the variable to which the parameter value will be assigned.
	// This value will be taken from the command line unless it is unavailable
	// thereof, in which case it will be taken from the configuration file.
	// If the value is absent from both, then a default value should have been
	// supplied when calling the constructor of the ParamProcessing class in
	// Data::Data.
	//    
	// ex.:
	// ParamProcessing paramProcessing	
	// paramProcessing.assignParamValue("ord", "evalOrd", evalOrder);
	// paramProcessing.assignParamValue("freq", "printFrequ", printFrequency);
	//
	// if the configuration file contains:
	//
	//  evalOrd AFTER
	//  printFrequ 1000
	//
	// and the command line contains:
	//
	// prog_exec -ord BEFORE
	//
	// then the variables evalOrder and printFrequency will be assigned values
	// as follows: 
	//
	// evalOrder = BEFORE, printFrequency = 1000.
	//

private:

	// mapping from name of parameter to its value, according to command line
	map<string, string> paramToValueMapFromCmdLine;

	// mapping from name of parameter to its value, according to configuration
	// file
	map<string, string> paramToValueMapFromConfigFile;
	
	// number of arguments in command line
	int nbArg;
	
	// array of char array containing the command line
	char **vectArg;
	
	// there are three possible locations of configuration files
	string configFileName[3];
	
	// flags display of parameter value when parsing
	bool verbose;	

	// These methods used in parsing configuration parameters:
	
	void parseCmdLine();
	
	void parseConfigFileNameFromCmdLine();
	
	void parseConfigFile(const string &nameInFile);
	
	string parseConfigLine(istringstream &ligneFichier);

};

const int lineLength = 256;

inline ParamProcessing::ParamProcessing(int argc, char **argv, string fileName) :
		nbArg(argc), vectArg(argv), verbose(false)
{
	// default configuration file name	
	configFileName[0] = DEFAULT_CONFIG_FILE_NAME;
	
	// configuration file name as passed to constructor
	configFileName[1] = fileName;
	
	// configuration file name specified on command line
	configFileName[2] = ""; 

	parseConfigFileNameFromCmdLine();

	// successively parsing the 3 possible configuration files
	for (int i = 0; i < 3; ++i)
		parseConfigFile(configFileName[i]);

	// parsing the command line
	parseCmdLine();
}

// Parses the configuration file name specified on command line
inline
void ParamProcessing::parseConfigFileNameFromCmdLine()
{
	int a;
	bool foundFile = false;

	for (a = 1; a < nbArg; a++)
	{
		if (vectArg[a][0] == CONFIG_PREFIX)
		{
			if (strcmp(vectArg[a], CONFIG_FILE_PREFIX) == 0)
			{
				// checks if configuration file name is specified on cmd line
				if (a < nbArg - 1)
				{
					configFileName[2] = vectArg[a + 1];
					foundFile = true;
				}
			}
			else if (strcmp(vectArg[a], CONFIG_VERBOSE_MODE) == 0)
			{
				verbose = true;
			}
			//
			else if (isalpha(vectArg[a][1]))
				cerr << "********* config prefix [" << vectArg[a]
						<< "] unknown.\n";
		}
	}

	if (verbose)
	{
		cout << "\n********* VERBOSE MODE *********\n\n";

		if (foundFile)
			cout << "********* config file name [" << CONFIG_FILE_PREFIX
					<< "] = [" << configFileName[2] << "]\n";
	}

}

// Parses the configuration parameter values supplied on command line.
inline
void ParamProcessing::parseCmdLine()
{
	int a = 1;
	const char *arg1;
	const char *arg2;

	while (a < nbArg)
	{
		if ((vectArg[a][0] == PARAM_PREFIX))
		{
			arg1 = &vectArg[a][1];

			if (a < nbArg - 1)
			{
				arg2 = vectArg[a + 1];

				if (((vectArg[a + 1][0] == PARAM_PREFIX)
						|| (vectArg[a + 1][0] == CONFIG_PREFIX))
						&& isalpha(vectArg[a + 1][1]))
					arg2 = "";
				else
					a++;
			}
			else
				arg2 = "";

			if (verbose)
				cout << "********* cmd line -- parameter [" << arg1 << "] = ["
						<< arg2 << "]\n";
			paramToValueMapFromCmdLine[arg1] = arg2;
		}

		a++;
	}

	if (verbose)
		cout << endl;
}

// Parses configuration parameter values supplied in configuration file.
inline
void ParamProcessing::parseConfigFile(const string &infileName)
{
	char line[lineLength];
	ifstream inStr;

	// attempt to open file
	inStr.open(infileName.c_str());

	// proceed to parsing if successful
	if (inStr)
	{
		if (verbose)
			cout << "\n********* configuration file = [" << infileName
					<< "]\n\n";
		inStr.getline(line, lineLength);
		while (inStr)
		{
			istringstream configLine(line);

			string str1;
			configLine >> str1;
			string str2 = parseConfigLine(configLine);

			int pos = (str1[0] == PARAM_PREFIX) ? 1 : 0;

			// ensures that it is not a comment
			if (isalpha(str1[pos]))

			{
				if (verbose)
					cout << "********* configuration file -- parameter ["
							<< str1.substr(pos) << "] = [" << str2 << "]\n";

				// stores in map
				paramToValueMapFromConfigFile[str1.substr(pos)] = str2;
			}

			inStr.getline(line, lineLength);
		}

		if (verbose)
			cout << "\n";
	}
}

// Parses a line of the configuration file.
inline string ParamProcessing::parseConfigLine(istringstream &configLine)
{
	char caract = '\0';
	string outFile("");

	configLine >> caract;

	if (configLine)
	{
		if (caract == '"')
		{
			char valeur[lineLength];
			valeur[0] = '\0';
			configLine.getline(valeur, lineLength, '"');
			outFile = valeur;
		}
		else
		{
			string str;
			configLine >> str;
			outFile = caract + str;
		}
	}

	return outFile;
}

// Determines value to be assigned to a parameter.
template<class T>
inline
bool ParamProcessing::assignParamValue(const string &cmdString,
		const string &configFileString, T &var) const
{
	bool ok = true;

	// attempt to retrieve from data collected from command line
	map<string, string>::const_iterator itL = paramToValueMapFromCmdLine.find(
			cmdString);

	if (itL != paramToValueMapFromCmdLine.end())
	{
		istringstream istr((*itL).second);
		istr >> var;
	}
	else
	{
		// if unavailable, attempt to retrieve from data collected from configuration file(s)
		map<string, string>::const_iterator itF =
				paramToValueMapFromConfigFile.find(configFileString);

		if (itF != paramToValueMapFromConfigFile.end())
		{
			istringstream istr((*itF).second);
			istr >> var;
		}
		else
			ok = false;
	}

	return ok;
}

// Determines value to be assigned to a parameter. Specialized to string.
inline
bool ParamProcessing::assignParamValue(const string &cmdString,
		const string &configFileString, string &var) const
{
	bool ok = true;

	// attempt to retrieve from data collected from command line
	map<string, string>::const_iterator itL = paramToValueMapFromCmdLine.find(
			cmdString);

	if (itL != paramToValueMapFromCmdLine.end())
		var = (*itL).second;
	else
	{
		// if unavailable, attempt to retrieve from data collected from configuration file(s)
		map<string, string>::const_iterator itF =
				paramToValueMapFromConfigFile.find(configFileString);

		if (itF != paramToValueMapFromConfigFile.end())
			var = (*itF).second;
		else
			ok = false;
	}

	return ok;
}

// Determines value to be assigned to a parameter. Specialized to char*.
inline
bool ParamProcessing::assignParamValue(const string &cmdString,
		const string &configFileString, char *var) const
{
	bool ok = true;

	// attempt to retrieve from data collected from command line
	map<string, string>::const_iterator itL = paramToValueMapFromCmdLine.find(
			cmdString);

	if (itL != paramToValueMapFromCmdLine.end())
		strcpy(var, (*itL).second.c_str());
	else
	{
		// if unavailable, attempt to retrieve from data collected from configuration file(s)
		map<string, string>::const_iterator itF =
				paramToValueMapFromConfigFile.find(configFileString);

		if (itF != paramToValueMapFromConfigFile.end())
			strcpy(var, (*itF).second.c_str());
		else
			ok = false;
	}

	return ok;
}

// Determines value to be assigned to a parameter. Specialized to bool.
inline
bool ParamProcessing::assignParamValue(const string &cmdString,
		const string &configFileString, bool &var) const
{
	bool ok = true;

	// attempt to retrieve from data collected from command line
	map<string, string>::const_iterator itL = paramToValueMapFromCmdLine.find(
			cmdString);

	if (itL != paramToValueMapFromCmdLine.end())
	{
		if ((*itL).second == "")
			var = DEFAULT_BOOL;
		else
		{
			istringstream istr((*itL).second);
			istr >> var;
		}
	}
	else
	{
		// if unavailable, attempt to retrieve from data collected from configuration file(s)
		map<string, string>::const_iterator itF =
				paramToValueMapFromConfigFile.find(configFileString);

		if (itF != paramToValueMapFromConfigFile.end())
		{
			if ((*itF).second == "")
				var = DEFAULT_BOOL;
			else
			{
				istringstream istr((*itF).second);
				istr >> var;
			}
		}
		else
			ok = false;
	}

	return ok;
}

}

#endif
